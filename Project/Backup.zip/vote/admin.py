from vote.models import Vote
from django.contrib import admin

# Register your models here.
admin.site.register(Vote)