from django.apps import AppConfig


class VoteConfig(AppConfig):
    name = 'vote'
