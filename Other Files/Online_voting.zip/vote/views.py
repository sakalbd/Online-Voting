from django.shortcuts import render

# Create your views here.

def result(request):
    pass

def vote(request):
    pass